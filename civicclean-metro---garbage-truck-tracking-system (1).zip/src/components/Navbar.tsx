import React, { useState } from 'react';
import { 
  Truck, 
  Bell, 
  MapPin, 
  Type, 
  ChevronDown, 
  ShieldCheck, 
  User, 
  LogOut,
  AlertCircle,
  Menu,
  X
} from 'lucide-react';
import { UserProfile, Ward, CivicNotification } from '../types';

interface NavbarProps {
  currentUser: UserProfile;
  currentWard: Ward;
  allWards: Ward[];
  onSelectWard: (ward: Ward) => void;
  isSeniorMode: boolean;
  onToggleSeniorMode: () => void;
  notifications: CivicNotification[];
  onOpenNotifications: () => void;
  onSwitchUser: (role: 'citizen' | 'admin' | 'driver') => void;
  onOpenMobileMenu: () => void;
  isMobileMenuOpen: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentUser,
  currentWard,
  allWards,
  onSelectWard,
  isSeniorMode,
  onToggleSeniorMode,
  notifications,
  onOpenNotifications,
  onSwitchUser,
  onOpenMobileMenu,
  isMobileMenuOpen,
}) => {
  const [showWardDropdown, setShowWardDropdown] = useState(false);
  const [showUserDropdown, setShowUserDropdown] = useState(false);

  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <header className="sticky top-0 z-40 bg-slate-900 border-b border-slate-800 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand Logo & Municipal Seal */}
          <div className="flex items-center gap-3">
            <button
              onClick={onOpenMobileMenu}
              className="lg:hidden p-2 rounded-md text-slate-300 hover:text-white hover:bg-slate-800"
              aria-label="Toggle Navigation Menu"
            >
              {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>

            <div className="flex items-center gap-2.5 cursor-pointer">
              <div className="w-9 h-9 rounded-lg bg-emerald-600 flex items-center justify-center text-white shadow-sm font-bold">
                <Truck className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-extrabold tracking-tight text-base sm:text-lg text-white">
                    CIVICCLEAN<span className="text-emerald-400">METRO</span>
                  </span>
                  <span className="hidden md:inline-block px-1.5 py-0.5 text-[10px] font-semibold bg-emerald-950 text-emerald-300 border border-emerald-800/80 rounded">
                    MUNICIPAL CORP
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 hidden sm:block">
                  Smart Waste Tracking & Citizen Services
                </p>
              </div>
            </div>
          </div>

          {/* Center: Ward Selector */}
          <div className="relative hidden md:block">
            <button
              onClick={() => setShowWardDropdown(!showWardDropdown)}
              className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 text-xs sm:text-sm text-slate-200 transition-colors"
            >
              <MapPin className="w-4 h-4 text-emerald-400 shrink-0" />
              <div className="text-left">
                <span className="text-[10px] block text-slate-400 uppercase tracking-wider font-semibold">Active Ward</span>
                <span className="font-medium text-slate-100">{currentWard.name.split(' - ')[0]} ({currentWard.zone.split(' ')[0]})</span>
              </div>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400 ml-1" />
            </button>

            {showWardDropdown && (
              <div className="absolute left-0 mt-2 w-72 bg-slate-900 border border-slate-700 rounded-lg shadow-2xl py-1 z-50 text-xs">
                <div className="px-3 py-2 border-b border-slate-800 text-[11px] text-slate-400 font-semibold uppercase tracking-wider">
                  Select Municipal Ward
                </div>
                {allWards.map((w) => (
                  <button
                    key={w.id}
                    onClick={() => {
                      onSelectWard(w);
                      setShowWardDropdown(false);
                    }}
                    className={`w-full text-left px-3 py-2.5 flex items-center justify-between hover:bg-slate-800 transition-colors ${
                      w.id === currentWard.id ? 'bg-emerald-950/50 text-emerald-400 font-medium' : 'text-slate-300'
                    }`}
                  >
                    <div>
                      <div className="font-medium">{w.name}</div>
                      <div className="text-[10px] text-slate-500">{w.zone} · {w.activeTruckCount} Trucks Active</div>
                    </div>
                    {w.id === currentWard.id && <span className="text-emerald-400 text-xs">✓ Active</span>}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Right Utilities */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Senior Mode Toggle Button */}
            <button
              onClick={onToggleSeniorMode}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-xs font-semibold transition-all ${
                isSeniorMode
                  ? 'bg-amber-400 text-slate-950 border-amber-300 shadow-md ring-2 ring-amber-300'
                  : 'bg-slate-800/80 text-slate-300 border-slate-700 hover:bg-slate-800 hover:text-white'
              }`}
              title="Toggle Large Text / Senior Accessible Mode"
            >
              <Type className="w-4 h-4" />
              <span className="hidden sm:inline">
                {isSeniorMode ? 'Senior Mode: ON' : 'Senior Mode'}
              </span>
            </button>

            {/* Notification Bell */}
            <button
              onClick={onOpenNotifications}
              className="relative p-2 rounded-lg bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 text-slate-300 hover:text-white transition-colors"
              aria-label="View civic notifications"
            >
              <Bell className="w-4 h-4" />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 flex h-4 min-w-4 px-1 items-center justify-center rounded-full bg-rose-500 text-[10px] font-bold text-white">
                  {unreadCount}
                </span>
              )}
            </button>

            {/* User Profile & Demo Switcher */}
            <div className="relative">
              <button
                onClick={() => setShowUserDropdown(!showUserDropdown)}
                className="flex items-center gap-2 pl-2 pr-2.5 py-1 rounded-lg bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 text-xs text-slate-200 transition-colors"
              >
                <img
                  src={currentUser.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80'}
                  alt={currentUser.name}
                  className="w-7 h-7 rounded-full object-cover border border-slate-600"
                />
                <div className="text-left hidden sm:block">
                  <span className="font-semibold block leading-tight text-slate-100 max-w-[110px] truncate">
                    {currentUser.name}
                  </span>
                  <span className="text-[10px] text-emerald-400 capitalize block">
                    {currentUser.role === 'citizen' ? 'Resident Citizen' : currentUser.role === 'admin' ? 'Sanitation Admin' : 'Fleet Driver'}
                  </span>
                </div>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              </button>

              {showUserDropdown && (
                <div className="absolute right-0 mt-2 w-64 bg-slate-900 border border-slate-700 rounded-lg shadow-2xl py-2 z-50 text-xs">
                  <div className="px-3 py-2 border-b border-slate-800">
                    <p className="font-semibold text-white">{currentUser.name}</p>
                    <p className="text-[11px] text-slate-400 truncate">{currentUser.email}</p>
                    <div className="mt-1 flex items-center gap-1.5 text-[10px] text-emerald-400 font-mono">
                      <ShieldCheck className="w-3 h-3" />
                      <span>{currentUser.badgeNumber ? `Badge: ${currentUser.badgeNumber}` : `Ward 4 Resident`}</span>
                    </div>
                  </div>

                  <div className="px-3 py-1.5 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                    Switch Demo View
                  </div>

                  <button
                    onClick={() => {
                      onSwitchUser('citizen');
                      setShowUserDropdown(false);
                    }}
                    className={`w-full text-left px-3 py-2 flex items-center gap-2 hover:bg-slate-800 transition-colors ${
                      currentUser.role === 'citizen' ? 'text-emerald-400 font-semibold' : 'text-slate-300'
                    }`}
                  >
                    <User className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Citizen View (Sarah Jenkins)</span>
                  </button>

                  <button
                    onClick={() => {
                      onSwitchUser('admin');
                      setShowUserDropdown(false);
                    }}
                    className={`w-full text-left px-3 py-2 flex items-center gap-2 hover:bg-slate-800 transition-colors ${
                      currentUser.role === 'admin' ? 'text-emerald-400 font-semibold' : 'text-slate-300'
                    }`}
                  >
                    <ShieldCheck className="w-3.5 h-3.5 text-sky-400" />
                    <span>Municipal Admin View (Chief Arthur)</span>
                  </button>

                  <button
                    onClick={() => {
                      onSwitchUser('driver');
                      setShowUserDropdown(false);
                    }}
                    className={`w-full text-left px-3 py-2 flex items-center gap-2 hover:bg-slate-800 transition-colors ${
                      currentUser.role === 'driver' ? 'text-emerald-400 font-semibold' : 'text-slate-300'
                    }`}
                  >
                    <Truck className="w-3.5 h-3.5 text-amber-400" />
                    <span>Driver View (Marcus Vance - GT-104)</span>
                  </button>

                  <div className="border-t border-slate-800 mt-2 pt-1">
                    <button
                      onClick={() => {
                        onSwitchUser('citizen');
                        setShowUserDropdown(false);
                      }}
                      className="w-full text-left px-3 py-1.5 text-rose-400 hover:bg-slate-800 flex items-center gap-2 text-xs"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      <span>Log Out / Reset Session</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
