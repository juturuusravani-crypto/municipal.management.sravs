import React, { useState, useEffect, useRef } from 'react';
import { Truck, LatLng } from '../../types';
import { 
  Navigation, 
  MapPin, 
  RotateCcw, 
  Play, 
  Pause, 
  FastForward, 
  Layers, 
  Compass, 
  CheckCircle2, 
  Clock, 
  Volume2, 
  AlertTriangle,
  Radio
} from 'lucide-react';

interface InteractiveTrackingMapProps {
  truck: Truck;
  userLocation?: LatLng;
  userAddress?: string;
  isSeniorMode?: boolean;
  onStopClick?: (stopIndex: number) => void;
  showAllTrucks?: boolean;
  allTrucks?: Truck[];
  onSelectTruck?: (truck: Truck) => void;
}

export const InteractiveTrackingMap: React.FC<InteractiveTrackingMapProps> = ({
  truck: initialTruck,
  userLocation = { x: 55, y: 38 },
  userAddress = '742 Evergreen Terrace (Ward 4)',
  isSeniorMode = false,
  onStopClick,
  showAllTrucks = false,
  allTrucks = [],
  onSelectTruck,
}) => {
  const [truck, setTruck] = useState<Truck>(initialTruck);
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [simSpeed, setSimSpeed] = useState<number>(1); // 1x, 2x, 4x
  const [mapStyle, setMapStyle] = useState<'streets' | 'satellite' | 'high_contrast'>('streets');
  const [zoomLevel, setZoomLevel] = useState<number>(1);
  const [panOffset, setPanOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [activeTooltip, setActiveTooltip] = useState<{
    type: 'truck' | 'stop' | 'home';
    title: string;
    description: string;
    x: number;
    y: number;
  } | null>(null);
  const [audioAnnounced, setAudioAnnounced] = useState<boolean>(false);

  // Sync if parent updates initialTruck
  useEffect(() => {
    setTruck(initialTruck);
  }, [initialTruck.id]);

  // Simulation loop: smooth movement along route stops
  useEffect(() => {
    if (!isPlaying) return;

    const interval = setInterval(() => {
      setTruck((prev) => {
        const stops = prev.routeStops;
        if (!stops || stops.length === 0) return prev;

        const currentStopIdx = prev.currentStopIndex;
        const targetStop = stops[Math.min(currentStopIdx, stops.length - 1)];
        if (!targetStop) return prev;

        const targetCoords = targetStop.coordinates;
        const dx = targetCoords.x - prev.currentLocation.x;
        const dy = targetCoords.y - prev.currentLocation.y;
        const dist = Math.hypot(dx, dy);

        // Step size based on simulation speed
        const step = 0.5 * simSpeed;

        if (dist <= step) {
          // Reached stop! Advance to next stop
          const nextIndex = (currentStopIdx + 1) % stops.length;
          const nextTarget = stops[nextIndex];
          const newHeading = Math.atan2(nextTarget.coordinates.y - targetCoords.y, nextTarget.coordinates.x - targetCoords.x) * (180 / Math.PI);
          
          const newEta = Math.max(0, (stops.length - 1 - nextIndex) * 3);
          const newDist = Math.round(dist * 50);

          return {
            ...prev,
            currentLocation: { ...targetCoords },
            currentStopIndex: nextIndex,
            heading: newHeading + 90,
            estimatedArrivalMinutes: newEta,
            distanceMeters: Math.max(120, (stops.length - 1 - nextIndex) * 220),
            status: nextIndex === 4 ? 'arriving' : nextIndex > 4 ? 'collected' : 'on_route',
          };
        } else {
          // Move towards target
          const newX = prev.currentLocation.x + (dx / dist) * step;
          const newY = prev.currentLocation.y + (dy / dist) * step;
          const headingAngle = Math.atan2(dy, dx) * (180 / Math.PI) + 90;

          // Estimate arrival based on distance to user (stop 4 / user location)
          const distToUser = Math.hypot(userLocation.x - newX, userLocation.y - newY);
          const etaMins = Math.max(1, Math.round(distToUser * 0.4));
          const distMeters = Math.round(distToUser * 35);

          return {
            ...prev,
            currentLocation: { x: Number(newX.toFixed(2)), y: Number(newY.toFixed(2)) },
            heading: headingAngle,
            estimatedArrivalMinutes: etaMins,
            distanceMeters: distMeters,
            status: etaMins <= 3 ? 'arriving' : 'on_route',
          };
        }
      });
    }, 400);

    return () => clearInterval(interval);
  }, [isPlaying, simSpeed, userLocation.x, userLocation.y]);

  const handleRecenterTruck = () => {
    setPanOffset({ x: 0, y: 0 });
    setZoomLevel(1);
    setActiveTooltip({
      type: 'truck',
      title: `Truck ${truck.truckNumber}`,
      description: `${truck.driverName} · ${truck.speedKmh} km/h · ETA: ${truck.estimatedArrivalMinutes} min`,
      x: truck.currentLocation.x,
      y: truck.currentLocation.y,
    });
  };

  const handleRecenterHome = () => {
    setPanOffset({ x: 0, y: 0 });
    setZoomLevel(1);
    setActiveTooltip({
      type: 'home',
      title: 'Your Home Pickup Point',
      description: userAddress,
      x: userLocation.x,
      y: userLocation.y,
    });
  };

  const playVoiceAnnouncement = () => {
    setAudioAnnounced(true);
    if ('speechSynthesis' in window) {
      const speech = new SpeechSynthesisUtterance(
        `Municipal Waste Alert. Garbage Truck ${truck.truckNumber} is ${truck.estimatedArrivalMinutes} minutes away from your street. Please keep your bins curbside.`
      );
      speech.rate = 0.95;
      speech.pitch = 1.0;
      window.speechSynthesis.speak(speech);
    }
    setTimeout(() => setAudioAnnounced(false), 3500);
  };

  // Generate route polyline points
  const routePointsString = truck.routeStops && truck.routeStops.length > 0
    ? truck.routeStops.map(s => `${s.coordinates.x * 8},${s.coordinates.y * 5.2}`).join(' ')
    : '100,200 300,220 500,280 650,210';

  const completedPointsString = truck.routeStops && truck.routeStops.length > 0
    ? truck.routeStops.slice(0, truck.currentStopIndex + 1).map(s => `${s.coordinates.x * 8},${s.coordinates.y * 5.2}`).join(' ')
    : '';

  return (
    <div className="relative w-full bg-slate-900 rounded-xl overflow-hidden shadow-md border border-slate-800 select-none">
      {/* Top Map HUD Bar */}
      <div className="absolute top-3 left-3 right-3 z-20 flex flex-wrap items-center justify-between gap-2 pointer-events-none">
        {/* Live Status Chip */}
        <div className="pointer-events-auto bg-slate-900/90 backdrop-blur-md border border-slate-700/80 px-3.5 py-1.5 rounded-lg flex items-center gap-3 shadow-lg text-xs text-white">
          <div className="flex items-center gap-2">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
            </span>
            <span className="font-semibold tracking-wide text-slate-200">LIVE GPS TELEMETRY</span>
          </div>
          <span className="text-slate-600">|</span>
          <div className="text-slate-300">
            <span className="font-medium text-emerald-400">{truck.truckNumber}</span> · {truck.status.replace('_', ' ').toUpperCase()}
          </div>
          <span className="text-slate-600">|</span>
          <div className="text-amber-300 font-mono font-medium">
            ETA: {truck.estimatedArrivalMinutes} MIN ({truck.distanceMeters}m)
          </div>
        </div>

        {/* Map Control Buttons */}
        <div className="pointer-events-auto flex items-center gap-1.5 bg-slate-900/90 backdrop-blur-md p-1 rounded-lg border border-slate-700/80 shadow-lg">
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            title={isPlaying ? 'Pause Simulation' : 'Resume Simulation'}
            className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-800 rounded transition-colors"
          >
            {isPlaying ? <Pause className="w-4 h-4 text-emerald-400" /> : <Play className="w-4 h-4 text-amber-400" />}
          </button>

          <button
            onClick={() => setSimSpeed(prev => (prev === 1 ? 2 : prev === 2 ? 4 : 1))}
            title="Simulation Speed"
            className="px-2 py-1 text-xs font-mono font-semibold text-slate-200 hover:bg-slate-800 rounded transition-colors"
          >
            {simSpeed}x
          </button>

          <span className="h-4 w-px bg-slate-700 mx-0.5"></span>

          <button
            onClick={handleRecenterTruck}
            title="Locate Truck"
            className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-800 rounded transition-colors"
          >
            <Navigation className="w-4 h-4 text-sky-400" />
          </button>

          <button
            onClick={handleRecenterHome}
            title="Locate My Home"
            className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-800 rounded transition-colors"
          >
            <MapPin className="w-4 h-4 text-rose-400" />
          </button>

          <span className="h-4 w-px bg-slate-700 mx-0.5"></span>

          {/* Voice Announcement CTA */}
          <button
            onClick={playVoiceAnnouncement}
            title="Simulate Voice Alert Announcement"
            className={`px-2.5 py-1 text-xs rounded font-medium flex items-center gap-1.5 transition-all ${
              audioAnnounced ? 'bg-emerald-600 text-white' : 'text-slate-200 hover:bg-slate-800'
            }`}
          >
            <Volume2 className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden sm:inline">Voice Alert</span>
          </button>
        </div>
      </div>

      {/* SVG Vector Interactive Map Canvas */}
      <div 
        className="w-full relative overflow-hidden" 
        style={{ height: isSeniorMode ? '540px' : '460px', touchAction: 'none' }}
      >
        <svg
          viewBox="0 0 800 520"
          className="w-full h-full object-cover transition-transform duration-300 ease-out"
          style={{
            transform: `scale(${zoomLevel}) translate(${panOffset.x}px, ${panOffset.y}px)`,
            background: mapStyle === 'satellite' ? '#0f172a' : '#0b1329',
          }}
        >
          {/* Map Definitions for Gradients & Patterns */}
          <defs>
            <linearGradient id="riverGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#0284c7" stopOpacity="0.45" />
              <stop offset="100%" stopColor="#0369a1" stopOpacity="0.35" />
            </linearGradient>

            <linearGradient id="routeGradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#10b981" />
              <stop offset="50%" stopColor="#34d399" />
              <stop offset="100%" stopColor="#06b6d4" />
            </linearGradient>

            <pattern id="streetGrid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#1e293b" strokeWidth="1" strokeOpacity="0.6" />
            </pattern>

            <pattern id="zoneBlocks" width="80" height="80" patternUnits="userSpaceOnUse">
              <rect x="4" y="4" width="72" height="72" rx="4" fill="#131e36" stroke="#1e2d4d" strokeWidth="1.2" />
            </pattern>
          </defs>

          {/* Background Map Blocks */}
          <rect width="800" height="520" fill="url(#zoneBlocks)" />
          <rect width="800" height="520" fill="url(#streetGrid)" opacity="0.4" />

          {/* River / Natural Park Area */}
          <path
            d="M 0,380 Q 200,340 380,410 T 800,360 L 800,520 L 0,520 Z"
            fill="url(#riverGrad)"
          />
          <text x="650" y="440" fill="#38bdf8" opacity="0.5" fontSize="12" fontWeight="600" letterSpacing="2">
            RIVERSIDE BASIN
          </text>

          {/* Civic Park Green Zone */}
          <rect x="520" y="50" width="220" height="130" rx="8" fill="#064e3b" fillOpacity="0.4" stroke="#059669" strokeWidth="1" strokeDasharray="4 4" />
          <text x="540" y="80" fill="#34d399" opacity="0.7" fontSize="11" fontWeight="700" letterSpacing="1">
            WARD 4 CIVIC GREEN PARK
          </text>

          {/* Major Streets / Arterial Roads */}
          {/* Avenue 1 Horizontal */}
          <path d="M 0,110 L 800,110" stroke="#334155" strokeWidth="14" strokeLinecap="round" />
          <path d="M 0,110 L 800,110" stroke="#fbbf24" strokeWidth="1.5" strokeDasharray="8 8" opacity="0.6" />
          <text x="30" y="104" fill="#94a3b8" fontSize="10" fontWeight="500">NORTH BOULEVARD</text>

          {/* Avenue 2 Horizontal */}
          <path d="M 0,260 L 800,260" stroke="#334155" strokeWidth="16" strokeLinecap="round" />
          <path d="M 0,260 L 800,260" stroke="#ffffff" strokeWidth="1.5" strokeDasharray="10 8" opacity="0.5" />
          <text x="30" y="254" fill="#94a3b8" fontSize="10" fontWeight="500">MAPLE AVENUE (CENTRAL ARTERY)</text>

          {/* Avenue 3 Horizontal */}
          <path d="M 0,400 L 800,400" stroke="#334155" strokeWidth="12" strokeLinecap="round" />

          {/* Vertical Streets */}
          <path d="M 180,0 L 180,520" stroke="#334155" strokeWidth="12" />
          <text x="186" y="30" fill="#64748b" fontSize="9" fontWeight="600" transform="rotate(90 186,30)">WEST 4TH ST</text>

          <path d="M 360,0 L 360,520" stroke="#334155" strokeWidth="14" />
          <path d="M 360,0 L 360,520" stroke="#fbbf24" strokeWidth="1" strokeDasharray="6 6" opacity="0.5" />
          <text x="366" y="30" fill="#64748b" fontSize="9" fontWeight="600" transform="rotate(90 366,30)">CIVIC CENTER ROAD</text>

          <path d="M 540,0 L 540,520" stroke="#334155" strokeWidth="12" />
          <text x="546" y="30" fill="#64748b" fontSize="9" fontWeight="600" transform="rotate(90 546,30)">EVERGREEN CORRIDOR</text>

          <path d="M 700,0 L 700,520" stroke="#334155" strokeWidth="10" />

          {/* Diagonal Connecting Streets */}
          <path d="M 180,110 L 360,260 L 540,260 L 700,400" stroke="#1e293b" strokeWidth="8" strokeLinejoin="round" />

          {/* Route Polyline (Full scheduled path) */}
          <polyline
            points={routePointsString}
            fill="none"
            stroke="#38bdf8"
            strokeWidth="5"
            strokeDasharray="6 6"
            strokeOpacity="0.4"
            strokeLinecap="round"
          />

          {/* Completed Route Segment */}
          {completedPointsString && (
            <polyline
              points={completedPointsString}
              fill="none"
              stroke="#10b981"
              strokeWidth="5"
              strokeOpacity="0.75"
              strokeLinecap="round"
            />
          )}

          {/* Animated Active Route Vector line towards current stop */}
          <line
            x1={truck.currentLocation.x * 8}
            y1={truck.currentLocation.y * 5.2}
            x2={userLocation.x * 8}
            y2={userLocation.y * 5.2}
            stroke="#34d399"
            strokeWidth="3.5"
            strokeDasharray="8 6"
            className="animate-pulse"
          />

          {/* Route Stops / Waypoints */}
          {truck.routeStops?.map((stop, index) => {
            const sx = stop.coordinates.x * 8;
            const sy = stop.coordinates.y * 5.2;
            const isCompleted = index < truck.currentStopIndex;
            const isCurrent = index === truck.currentStopIndex;
            const isUserStop = index === 4;

            return (
              <g
                key={stop.id}
                className="cursor-pointer transition-transform hover:scale-110"
                onClick={() => {
                  setActiveTooltip({
                    type: 'stop',
                    title: `Stop #${index + 1}: ${stop.name}`,
                    description: `${stop.address} · Est: ${stop.timeEstimate} · ${stop.households} Homes · ${stop.wasteType.toUpperCase()}`,
                    x: stop.coordinates.x,
                    y: stop.coordinates.y,
                  });
                  if (onStopClick) onStopClick(index);
                }}
              >
                {/* Outer halo for active stop */}
                {isCurrent && (
                  <circle
                    cx={sx}
                    cy={sy}
                    r="16"
                    fill="#10b981"
                    fillOpacity="0.25"
                    className="animate-ping origin-center"
                  />
                )}

                {/* Stop Marker Circle */}
                <circle
                  cx={sx}
                  cy={sy}
                  r={isUserStop ? "11" : "8"}
                  fill={isCompleted ? "#059669" : isCurrent ? "#10b981" : "#1e293b"}
                  stroke={isUserStop ? "#f43f5e" : isCompleted ? "#34d399" : "#64748b"}
                  strokeWidth={isUserStop ? "3" : "2"}
                />

                {/* Stop Number or Icon */}
                <text
                  x={sx}
                  y={sy + 3.5}
                  textAnchor="middle"
                  fill="#ffffff"
                  fontSize={isUserStop ? "10" : "8"}
                  fontWeight="bold"
                >
                  {isCompleted ? "✓" : index + 1}
                </text>

                {/* Stop Label */}
                <text
                  x={sx}
                  y={sy + 18}
                  textAnchor="middle"
                  fill={isUserStop ? "#fb7185" : "#cbd5e1"}
                  fontSize={isSeniorMode ? "11" : "9"}
                  fontWeight={isUserStop ? "700" : "500"}
                  className="pointer-events-none"
                >
                  {stop.name}
                </text>
              </g>
            );
          })}

          {/* User's Home Location Marker */}
          <g
            className="cursor-pointer"
            onClick={handleRecenterHome}
          >
            {/* Pulsing Beacon Ring */}
            <circle
              cx={userLocation.x * 8}
              cy={userLocation.y * 5.2}
              r="24"
              fill="#f43f5e"
              fillOpacity="0.18"
              className="animate-ping origin-center"
            />
            <circle
              cx={userLocation.x * 8}
              cy={userLocation.y * 5.2}
              r="14"
              fill="#f43f5e"
              fillOpacity="0.3"
            />
            {/* Central Pin */}
            <circle
              cx={userLocation.x * 8}
              cy={userLocation.y * 5.2}
              r="8"
              fill="#e11d48"
              stroke="#ffffff"
              strokeWidth="2.5"
            />
            <text
              x={userLocation.x * 8}
              y={userLocation.y * 5.2 - 14}
              textAnchor="middle"
              fill="#fda4af"
              fontSize={isSeniorMode ? "12" : "10"}
              fontWeight="bold"
              stroke="#0f172a"
              strokeWidth="3"
              paintOrder="stroke"
            >
              ★ YOUR RESIDENCE
            </text>
          </g>

          {/* Show Other Fleet Trucks if in Multi-Truck or Admin mode */}
          {showAllTrucks && allTrucks.map((otherTruck) => {
            if (otherTruck.id === truck.id) return null;
            const otx = otherTruck.currentLocation.x * 8;
            const oty = otherTruck.currentLocation.y * 5.2;

            return (
              <g
                key={otherTruck.id}
                className="cursor-pointer hover:scale-110 transition-transform"
                onClick={() => onSelectTruck?.(otherTruck)}
              >
                <circle
                  cx={otx}
                  cy={oty}
                  r="10"
                  fill={otherTruck.status === 'delayed' ? '#f59e0b' : '#38bdf8'}
                  stroke="#ffffff"
                  strokeWidth="1.5"
                />
                <text
                  x={otx}
                  y={oty + 3}
                  textAnchor="middle"
                  fill="#ffffff"
                  fontSize="7"
                  fontWeight="bold"
                >
                  {otherTruck.truckNumber.replace('GT-', '')}
                </text>
                <text
                  x={otx}
                  y={oty + 18}
                  textAnchor="middle"
                  fill="#94a3b8"
                  fontSize="8"
                >
                  {otherTruck.truckNumber}
                </text>
              </g>
            );
          })}

          {/* Active Moving Garbage Truck Marker */}
          <g
            transform={`translate(${truck.currentLocation.x * 8}, ${truck.currentLocation.y * 5.2})`}
            className="cursor-pointer"
            onClick={handleRecenterTruck}
          >
            {/* Live Radar Pulse Effect */}
            <circle
              cx="0"
              cy="0"
              r="28"
              fill="#10b981"
              fillOpacity="0.2"
              className="animate-ping"
            />
            <circle
              cx="0"
              cy="0"
              r="18"
              fill="#065f46"
              fillOpacity="0.4"
            />

            {/* Rotated Truck Body */}
            <g transform={`rotate(${truck.heading})`}>
              {/* Truck Chassis Shadow */}
              <rect x="-10" y="-18" width="20" height="36" rx="4" fill="#022c22" opacity="0.6" />
              {/* Truck Cabin & Cargo Body */}
              <rect x="-9" y="-16" width="18" height="32" rx="3" fill="#10b981" stroke="#ffffff" strokeWidth="2" />
              {/* Cabin Glass Windshield */}
              <rect x="-7" y="-14" width="14" height="8" rx="2" fill="#0f172a" />
              {/* Compactor Body Grooves */}
              <line x1="-7" y1="2" x2="7" y2="2" stroke="#047857" strokeWidth="1.5" />
              <line x1="-7" y1="7" x2="7" y2="7" stroke="#047857" strokeWidth="1.5" />
              {/* Flashing Roof Beacon */}
              <circle cx="0" cy="-6" r="3" fill="#fbbf24" className="animate-pulse" />
            </g>

            {/* Vehicle Number Badge Label */}
            <rect
              x="-36"
              y="22"
              width="72"
              height="20"
              rx="4"
              fill="#0f172a"
              stroke="#10b981"
              strokeWidth="1.5"
            />
            <text
              x="0"
              y="35"
              textAnchor="middle"
              fill="#34d399"
              fontSize="10"
              fontWeight="bold"
            >
              🚛 {truck.truckNumber}
            </text>
          </g>
        </svg>

        {/* Floating Tooltip Card */}
        {activeTooltip && (
          <div
            className="absolute z-30 bg-slate-900/95 text-white p-3 rounded-lg border border-slate-700 shadow-xl max-w-xs transition-all pointer-events-auto"
            style={{
              left: `${Math.min(75, Math.max(10, activeTooltip.x))}%`,
              top: `${Math.min(75, Math.max(15, activeTooltip.y))}%`,
              transform: 'translate(-50%, -115%)',
            }}
          >
            <div className="flex items-center justify-between gap-3 mb-1">
              <span className="font-bold text-sm text-emerald-400">{activeTooltip.title}</span>
              <button
                onClick={() => setActiveTooltip(null)}
                className="text-slate-400 hover:text-white text-xs px-1"
              >
                ✕
              </button>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">{activeTooltip.description}</p>
          </div>
        )}
      </div>

      {/* Bottom Map Legend & Quick Telemetry Tray */}
      <div className="bg-slate-950 px-4 py-2.5 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center flex-wrap gap-4 text-slate-400">
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-emerald-500 inline-block"></span>
            <span>Active Truck ({truck.speedKmh} km/h)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-rose-500 inline-block"></span>
            <span>Your Residence</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-slate-700 border border-slate-500 inline-block"></span>
            <span>Completed Stops</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-4 h-0.5 border-t border-dashed border-emerald-400 inline-block"></span>
            <span>Next Arrival Corridor</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setZoomLevel(prev => Math.min(prev + 0.25, 2.5))}
            className="w-7 h-7 flex items-center justify-center bg-slate-800 text-slate-200 hover:bg-slate-700 rounded text-sm font-bold"
            title="Zoom In"
          >
            +
          </button>
          <button
            onClick={() => setZoomLevel(prev => Math.max(prev - 0.25, 0.75))}
            className="w-7 h-7 flex items-center justify-center bg-slate-800 text-slate-200 hover:bg-slate-700 rounded text-sm font-bold"
            title="Zoom Out"
          >
            -
          </button>
          <button
            onClick={() => {
              setZoomLevel(1);
              setPanOffset({ x: 0, y: 0 });
            }}
            className="px-2 py-1 bg-slate-800 text-slate-300 hover:bg-slate-700 rounded text-xs"
            title="Reset View"
          >
            Reset
          </button>
        </div>
      </div>
    </div>
  );
};
