export type UserRole = 'citizen' | 'admin' | 'driver';

export interface UserProfile {
  id: string;
  name: string;
  role: UserRole;
  email: string;
  phone: string;
  wardId: string;
  address: string;
  badgeNumber?: string;
  avatar?: string;
}

export type TruckStatus = 'on_route' | 'arriving' | 'collected' | 'delayed' | 'in_depot' | 'maintenance';

export type WasteType = 'organic' | 'recyclable' | 'hazardous' | 'bulky' | 'general';

export interface LatLng {
  x: number; // 0 to 100 on our interactive grid system
  y: number; // 0 to 100 on our interactive grid system
}

export interface RouteStop {
  id: string;
  name: string;
  address: string;
  timeEstimate: string;
  status: 'completed' | 'current' | 'upcoming';
  wasteType: WasteType;
  coordinates: LatLng;
  households: number;
}

export interface Truck {
  id: string;
  truckNumber: string;
  plateNumber: string;
  model: string;
  capacityTons: number;
  currentLoadPercentage: number;
  fuelPercentage: number;
  speedKmh: number;
  driverName: string;
  driverPhone: string;
  driverRating: number;
  driverAvatar: string;
  helperName: string;
  wardId: string;
  wardName: string;
  status: TruckStatus;
  estimatedArrivalMinutes: number;
  distanceMeters: number;
  currentLocation: LatLng;
  heading: number; // degrees for truck icon rotation
  routeStops: RouteStop[];
  currentStopIndex: number;
  lastUpdated: string;
  delayReason?: string;
}

export interface Ward {
  id: string;
  name: string;
  zone: string;
  population: number;
  households: number;
  inspectorName: string;
  inspectorPhone: string;
  collectionDays: string[];
  activeTruckCount: number;
  completionRate: number;
}

export interface ScheduleItem {
  id: string;
  wardId: string;
  wardName: string;
  dayOfWeek: string;
  date: string;
  timeSlot: string;
  wasteType: WasteType;
  truckNumber: string;
  driverName: string;
  status: 'scheduled' | 'in_progress' | 'completed' | 'delayed' | 'cancelled';
  notes?: string;
}

export type ComplaintType = 'missed_collection' | 'overflowing_bin' | 'damaged_bin' | 'illegal_dumping' | 'spillage' | 'driver_issue';

export interface Complaint {
  id: string;
  ticketNumber: string;
  citizenName: string;
  citizenPhone: string;
  wardId: string;
  wardName: string;
  locationAddress: string;
  complaintType: ComplaintType;
  description: string;
  urgency: 'low' | 'medium' | 'high';
  status: 'submitted' | 'assigned' | 'in_progress' | 'resolved';
  submittedAt: string;
  updatedAt: string;
  assignedStaff?: string;
  resolutionNotes?: string;
  photoUrl?: string;
  resolvedPhotoUrl?: string;
}

export interface CivicNotification {
  id: string;
  type: 'arrival' | 'completed' | 'delay' | 'schedule_change' | 'emergency';
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  truckNumber?: string;
  wardId?: string;
  priority: 'normal' | 'high' | 'critical';
}

export interface FleetStats {
  totalTrucks: number;
  operatingTrucks: number;
  completedCollections: number;
  delayedTrucks: number;
  openComplaints: number;
  dailyTonsCollected: number;
  dailyTargetHouseholds: number;
  completedHouseholds: number;
}
