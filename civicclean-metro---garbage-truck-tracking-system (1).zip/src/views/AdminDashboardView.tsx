import React, { useState } from 'react';
import { 
  Truck, 
  CheckCircle2, 
  AlertTriangle, 
  Clock, 
  MapPin, 
  Radio, 
  ShieldCheck, 
  Send, 
  Users, 
  Activity, 
  ArrowUpRight,
  TrendingUp,
  FileWarning,
  Layers,
  Sparkles
} from 'lucide-react';
import { Truck as TruckType, Ward, FleetStats } from '../types';
import { InteractiveTrackingMap } from '../components/map/InteractiveTrackingMap';
import { ScreenId } from '../components/Sidebar';

interface AdminDashboardViewProps {
  stats: FleetStats;
  trucks: TruckType[];
  wards: Ward[];
  selectedTruck: TruckType;
  onSelectTruck: (truck: TruckType) => void;
  onNavigate: (screen: ScreenId) => void;
  onBroadcastAlert: (title: string, message: string, wardId: string) => void;
  isSeniorMode: boolean;
}

export const AdminDashboardView: React.FC<AdminDashboardViewProps> = ({
  stats,
  trucks,
  wards,
  selectedTruck,
  onSelectTruck,
  onNavigate,
  onBroadcastAlert,
  isSeniorMode,
}) => {
  const [broadcastWard, setBroadcastWard] = useState<string>('all');
  const [broadcastTitle, setBroadcastTitle] = useState<string>('');
  const [broadcastMessage, setBroadcastMessage] = useState<string>('');
  const [broadcastSuccess, setBroadcastSuccess] = useState<boolean>(false);
  const [filterStatus, setFilterStatus] = useState<'all' | 'delayed' | 'on_route'>('all');

  const handleSendBroadcast = (e: React.FormEvent) => {
    e.preventDefault();
    if (!broadcastTitle || !broadcastMessage) return;
    onBroadcastAlert(broadcastTitle, broadcastMessage, broadcastWard);
    setBroadcastSuccess(true);
    setBroadcastTitle('');
    setBroadcastMessage('');
    setTimeout(() => setBroadcastSuccess(false), 3000);
  };

  const filteredTrucks = trucks.filter((t) => {
    if (filterStatus === 'delayed') return t.status === 'delayed';
    if (filterStatus === 'on_route') return t.status === 'on_route' || t.status === 'arriving';
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-sky-950 text-sky-300 border border-sky-800 uppercase tracking-wider">
              MUNICIPAL DISPATCH HEADQUARTERS
            </span>
            <span className="text-emerald-400 text-xs font-mono">● SYSTEM ONLINE</span>
          </div>
          <h1 className={`font-extrabold text-white tracking-tight mt-1 ${isSeniorMode ? 'text-3xl' : 'text-2xl'}`}>
            Central Waste Fleet Telemetry Command
          </h1>
          <p className="text-xs sm:text-sm text-slate-400">
            Real-time municipal fleet routing, household pickup telemetry, and incident dispatch
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigate('fleet_management')}
            className="px-3.5 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs flex items-center gap-1.5 transition-colors shadow-md shadow-sky-950"
          >
            <Truck className="w-4 h-4" />
            <span>Manage Fleet & Drivers</span>
          </button>

          <button
            onClick={() => onNavigate('analytics')}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold text-xs flex items-center gap-1.5 transition-colors"
          >
            <Activity className="w-4 h-4 text-emerald-400" />
            <span>Analytics & Reports</span>
          </button>
        </div>
      </div>

      {/* KPI Telemetry Banner Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-6 gap-3 sm:gap-4">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">Total Fleet</span>
          <div className="text-2xl sm:text-3xl font-extrabold text-white font-mono mt-1">
            {stats.totalTrucks}
          </div>
          <span className="text-[10px] text-slate-500">Across 6 Wards</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">Operating Now</span>
          <div className="text-2xl sm:text-3xl font-extrabold text-emerald-400 font-mono mt-1">
            {stats.operatingTrucks}
          </div>
          <span className="text-[10px] text-emerald-500/80">Active GPS Beacon</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">Households Served</span>
          <div className="text-2xl sm:text-3xl font-extrabold text-sky-400 font-mono mt-1">
            {stats.completedHouseholds.toLocaleString()}
          </div>
          <span className="text-[10px] text-slate-500">81% Daily Target</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">Tons Collected</span>
          <div className="text-2xl sm:text-3xl font-extrabold text-amber-400 font-mono mt-1">
            {stats.dailyTonsCollected} <span className="text-xs">T</span>
          </div>
          <span className="text-[10px] text-slate-500">Dispatched to Depot</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">Delayed Routes</span>
          <div className="text-2xl sm:text-3xl font-extrabold text-rose-400 font-mono mt-1">
            {stats.delayedTrucks}
          </div>
          <span className="text-[10px] text-rose-400/80">Road & Traffic Flags</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">Open Complaints</span>
          <div className="text-2xl sm:text-3xl font-extrabold text-purple-400 font-mono mt-1">
            {stats.openComplaints}
          </div>
          <span className="text-[10px] text-slate-500">Avg SLA 2.4 hrs</span>
        </div>
      </div>

      {/* Main Multi-Truck Live Map */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <span>City-Wide Garbage Fleet Map</span>
              <span className="text-xs px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800">
                All 6 Wards
              </span>
            </h2>
            <p className="text-xs text-slate-400">Click any truck or stop marker to inspect telemetry</p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400 font-medium">Filter Map:</span>
            <div className="flex p-0.5 bg-slate-800 rounded-lg text-xs">
              <button
                onClick={() => setFilterStatus('all')}
                className={`px-2.5 py-1 rounded-md font-semibold transition-all ${
                  filterStatus === 'all' ? 'bg-slate-700 text-white' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                All Trucks ({trucks.length})
              </button>
              <button
                onClick={() => setFilterStatus('delayed')}
                className={`px-2.5 py-1 rounded-md font-semibold transition-all ${
                  filterStatus === 'delayed' ? 'bg-rose-900 text-white' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Delayed Only ({trucks.filter(t => t.status === 'delayed').length})
              </button>
            </div>
          </div>
        </div>

        <InteractiveTrackingMap
          truck={selectedTruck}
          showAllTrucks={true}
          allTrucks={filteredTrucks}
          onSelectTruck={(t) => onSelectTruck(t)}
          isSeniorMode={isSeniorMode}
        />
      </div>

      {/* Active Fleet Grid & Emergency Broadcast Console */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Operating Fleet Roster */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm">
          <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-800">
            <h3 className="font-bold text-white text-base">Active Fleet Operations</h3>
            <button
              onClick={() => onNavigate('fleet_management')}
              className="text-xs text-sky-400 hover:underline font-semibold"
            >
              Full Fleet Directory →
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 uppercase tracking-wider text-[10px]">
                  <th className="pb-2.5">Truck ID</th>
                  <th className="pb-2.5">Driver & Crew</th>
                  <th className="pb-2.5">Assigned Ward</th>
                  <th className="pb-2.5">Load %</th>
                  <th className="pb-2.5">Status</th>
                  <th className="pb-2.5 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {trucks.map((t) => (
                  <tr
                    key={t.id}
                    onClick={() => onSelectTruck(t)}
                    className={`hover:bg-slate-800/40 cursor-pointer transition-colors ${
                      t.id === selectedTruck.id ? 'bg-slate-800/60' : ''
                    }`}
                  >
                    <td className="py-3 font-mono font-bold text-white flex items-center gap-1.5">
                      <Truck className="w-3.5 h-3.5 text-emerald-400" />
                      <span>{t.truckNumber}</span>
                    </td>
                    <td className="py-3">
                      <div className="font-medium text-slate-200">{t.driverName}</div>
                      <div className="text-[10px] text-slate-400 font-mono">{t.driverPhone}</div>
                    </td>
                    <td className="py-3 text-slate-300">{t.wardName}</td>
                    <td className="py-3 font-mono">
                      <span className={`${t.currentLoadPercentage > 85 ? 'text-amber-400 font-bold' : 'text-slate-300'}`}>
                        {t.currentLoadPercentage}%
                      </span>
                    </td>
                    <td className="py-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                        t.status === 'on_route'
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                          : t.status === 'delayed'
                          ? 'bg-rose-950 text-rose-300 border border-rose-800'
                          : t.status === 'arriving'
                          ? 'bg-amber-950 text-amber-300 border border-amber-800'
                          : 'bg-slate-800 text-slate-400'
                      }`}>
                        {t.status.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="py-3 text-right">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectTruck(t);
                          onNavigate('live_tracking');
                        }}
                        className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] font-semibold"
                      >
                        Track
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right Col: Instant Citizen Broadcast Console */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-800">
            <Radio className="w-5 h-5 text-sky-400 animate-pulse" />
            <h3 className="font-bold text-white text-base">Broadcast Civic Alert</h3>
          </div>

          <p className="text-xs text-slate-400 leading-relaxed">
            Dispatch urgent SMS and push notifications to citizens for route delays or weather adjustments.
          </p>

          {broadcastSuccess && (
            <div className="p-3 bg-emerald-950/60 border border-emerald-500/80 rounded-xl text-emerald-300 text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>Broadcast dispatched to all citizens in selected sector!</span>
            </div>
          )}

          <form onSubmit={handleSendBroadcast} className="space-y-3 text-xs">
            <div>
              <label className="block text-slate-400 font-semibold mb-1">Target Ward</label>
              <select
                value={broadcastWard}
                onChange={(e) => setBroadcastWard(e.target.value)}
                className="w-full p-2 bg-slate-800 border border-slate-700 rounded-lg text-white"
              >
                <option value="all">All City Wards (Metro-wide)</option>
                {wards.map((w) => (
                  <option key={w.id} value={w.id}>
                    {w.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-400 font-semibold mb-1">Alert Headline</label>
              <input
                type="text"
                value={broadcastTitle}
                onChange={(e) => setBroadcastTitle(e.target.value)}
                placeholder="e.g. Route Delay: Road resurfacing"
                className="w-full p-2 bg-slate-800 border border-slate-700 rounded-lg text-white"
                required
              />
            </div>

            <div>
              <label className="block text-slate-400 font-semibold mb-1">Notice Message</label>
              <textarea
                value={broadcastMessage}
                onChange={(e) => setBroadcastMessage(e.target.value)}
                rows={3}
                placeholder="Provide instructions to residents..."
                className="w-full p-2 bg-slate-800 border border-slate-700 rounded-lg text-white"
                required
              ></textarea>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 px-4 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md shadow-sky-950 transition-colors"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Broadcast Alert to Residents</span>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
