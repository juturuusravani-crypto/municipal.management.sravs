import React, { useState } from 'react';
import { 
  Truck, 
  MapPin, 
  Phone, 
  Clock, 
  Gauge, 
  BatteryCharging, 
  CheckCircle2, 
  AlertTriangle, 
  Radio, 
  Volume2, 
  Sparkles,
  ChevronRight,
  Shield,
  Layers,
  User
} from 'lucide-react';
import { Truck as TruckType, Ward, UserProfile } from '../types';
import { InteractiveTrackingMap } from '../components/map/InteractiveTrackingMap';

interface LiveTrackingViewProps {
  currentTruck: TruckType;
  allTrucks: TruckType[];
  onSelectTruck: (truck: TruckType) => void;
  currentUser: UserProfile;
  currentWard: Ward;
  isSeniorMode: boolean;
}

export const LiveTrackingView: React.FC<LiveTrackingViewProps> = ({
  currentTruck,
  allTrucks,
  onSelectTruck,
  currentUser,
  currentWard,
  isSeniorMode,
}) => {
  const [showCallModal, setShowCallModal] = useState(false);
  const [selectedStopIdx, setSelectedStopIdx] = useState<number>(4);
  const [isCalling, setIsCalling] = useState(false);
  const [callEnded, setCallEnded] = useState(false);

  const handleSimulateCall = () => {
    setIsCalling(true);
    setCallEnded(false);
    setTimeout(() => {
      setIsCalling(false);
      setCallEnded(true);
      setTimeout(() => {
        setShowCallModal(false);
        setCallEnded(false);
      }, 2500);
    }, 2000);
  };

  const getStatusBadge = (status: TruckType['status']) => {
    switch (status) {
      case 'arriving':
        return (
          <span className="px-2.5 py-1 text-xs font-bold rounded-lg bg-amber-950 text-amber-300 border border-amber-800 animate-pulse flex items-center gap-1.5">
            <Radio className="w-3 h-3" />
            <span>ARRIVING SOON</span>
          </span>
        );
      case 'on_route':
        return (
          <span className="px-2.5 py-1 text-xs font-bold rounded-lg bg-emerald-950 text-emerald-300 border border-emerald-800 flex items-center gap-1.5">
            <Truck className="w-3 h-3" />
            <span>ON ROUTE</span>
          </span>
        );
      case 'collected':
        return (
          <span className="px-2.5 py-1 text-xs font-bold rounded-lg bg-sky-950 text-sky-300 border border-sky-800 flex items-center gap-1.5">
            <CheckCircle2 className="w-3 h-3" />
            <span>COLLECTED</span>
          </span>
        );
      case 'delayed':
        return (
          <span className="px-2.5 py-1 text-xs font-bold rounded-lg bg-rose-950 text-rose-300 border border-rose-800 flex items-center gap-1.5">
            <AlertTriangle className="w-3 h-3" />
            <span>DELAYED</span>
          </span>
        );
      default:
        return (
          <span className="px-2.5 py-1 text-xs font-bold rounded-lg bg-slate-800 text-slate-300 border border-slate-700">
            {status.toUpperCase()}
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header & Truck Switcher */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className={`font-extrabold text-white tracking-tight ${isSeniorMode ? 'text-3xl' : 'text-2xl'}`}>
              Live Garbage Truck GPS Tracking
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Real-time coordinates, route progress, and collection stops for {currentWard.name}
          </p>
        </div>

        {/* Truck Switcher Pill list */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          <span className="text-xs text-slate-400 shrink-0 font-medium">Select Truck:</span>
          {allTrucks.map((t) => (
            <button
              key={t.id}
              onClick={() => onSelectTruck(t)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-1.5 ${
                t.id === currentTruck.id
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              <Truck className="w-3.5 h-3.5" />
              <span>{t.truckNumber}</span>
              {t.status === 'delayed' && <span className="w-2 h-2 rounded-full bg-rose-500"></span>}
            </button>
          ))}
        </div>
      </div>

      {/* Main Interactive Map Component */}
      <div className="w-full">
        <InteractiveTrackingMap
          truck={currentTruck}
          userAddress={currentUser.address}
          userLocation={{ x: 55, y: 38 }}
          isSeniorMode={isSeniorMode}
          onStopClick={(idx) => setSelectedStopIdx(idx)}
        />
      </div>

      {/* Telemetry and Driver Info Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Col 1 & 2: Active Telemetry & Stop Sequence */}
        <div className="lg:col-span-2 space-y-6">
          {/* Key Metrics Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl">
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">Arrival ETA</span>
              <div className="text-xl sm:text-2xl font-extrabold text-amber-400 font-mono mt-1">
                {currentTruck.estimatedArrivalMinutes} MIN
              </div>
              <span className="text-[10px] text-slate-500">Live calculating</span>
            </div>

            <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl">
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">Distance</span>
              <div className="text-xl sm:text-2xl font-extrabold text-emerald-400 font-mono mt-1">
                {currentTruck.distanceMeters}m
              </div>
              <span className="text-[10px] text-slate-500">From your residence</span>
            </div>

            <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl">
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">Vehicle Speed</span>
              <div className="text-xl sm:text-2xl font-extrabold text-white font-mono mt-1">
                {currentTruck.speedKmh} km/h
              </div>
              <span className="text-[10px] text-slate-500">Safe municipal speed</span>
            </div>

            <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl">
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">Compactor Load</span>
              <div className="text-xl sm:text-2xl font-extrabold text-sky-400 font-mono mt-1">
                {currentTruck.currentLoadPercentage}%
              </div>
              <span className="text-[10px] text-slate-500">{currentTruck.capacityTons} Ton Max</span>
            </div>
          </div>

          {/* Route Stops Checklist */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-800">
              <div>
                <h3 className="font-bold text-white text-base">Route Waypoint Progress</h3>
                <p className="text-xs text-slate-400">Sequential stops along Ward 4 collection corridor</p>
              </div>
              <span className="text-xs font-mono text-emerald-400">
                Stop {currentTruck.currentStopIndex + 1} of {currentTruck.routeStops?.length || 8}
              </span>
            </div>

            <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
              {currentTruck.routeStops?.map((stop, index) => {
                const isCompleted = index < currentTruck.currentStopIndex;
                const isCurrent = index === currentTruck.currentStopIndex;
                const isUserStop = index === 4;

                return (
                  <div
                    key={stop.id}
                    onClick={() => setSelectedStopIdx(index)}
                    className={`p-3 rounded-xl border flex items-center justify-between transition-all cursor-pointer ${
                      isCurrent
                        ? 'bg-emerald-950/40 border-emerald-500/80 shadow-sm'
                        : isUserStop
                        ? 'bg-rose-950/20 border-rose-800/80'
                        : isCompleted
                        ? 'bg-slate-900/60 border-slate-800/60 opacity-80'
                        : 'bg-slate-900 border-slate-800'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold ${
                        isCompleted
                          ? 'bg-emerald-600 text-white'
                          : isCurrent
                          ? 'bg-amber-500 text-slate-950 animate-pulse'
                          : 'bg-slate-800 text-slate-400'
                      }`}>
                        {isCompleted ? '✓' : index + 1}
                      </div>

                      <div>
                        <div className="flex items-center gap-2">
                          <span className={`text-xs font-bold ${isUserStop ? 'text-rose-400' : 'text-white'}`}>
                            {stop.name}
                          </span>
                          {isUserStop && (
                            <span className="px-1.5 py-0.5 text-[9px] font-bold rounded bg-rose-950 text-rose-300 border border-rose-800">
                              YOUR PICKUP
                            </span>
                          )}
                          {isCurrent && (
                            <span className="px-1.5 py-0.5 text-[9px] font-bold rounded bg-amber-950 text-amber-300 border border-amber-800">
                              TRUCK HERE
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-slate-400">{stop.address} · {stop.households} Households</p>
                      </div>
                    </div>

                    <div className="text-right">
                      <span className="text-xs font-mono font-medium text-slate-300 block">{stop.timeEstimate}</span>
                      <span className="text-[10px] text-slate-500 capitalize">{stop.wasteType}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Col 3: Driver Details & Vehicle Info */}
        <div className="space-y-6">
          {/* Driver Card */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm">
            <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-800">
              <h3 className="font-bold text-white text-base">Assigned Driver</h3>
              <span className="text-xs text-amber-400 font-semibold">★ {currentTruck.driverRating}</span>
            </div>

            <div className="flex items-center gap-4">
              <img
                src={currentTruck.driverAvatar}
                alt={currentTruck.driverName}
                className="w-14 h-14 rounded-full object-cover border-2 border-emerald-500"
              />
              <div>
                <h4 className="font-bold text-white text-base">{currentTruck.driverName}</h4>
                <p className="text-xs text-slate-400">Chief Route Operator</p>
                <div className="flex items-center gap-1.5 text-xs text-emerald-400 mt-1">
                  <Shield className="w-3.5 h-3.5" />
                  <span>Licensed Municipal Driver</span>
                </div>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-800 space-y-2 text-xs">
              <div className="flex justify-between text-slate-400">
                <span>Sanitation Helper:</span>
                <span className="text-white font-medium">{currentTruck.helperName}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Direct Contact:</span>
                <span className="text-white font-mono">{currentTruck.driverPhone}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Shift Duration:</span>
                <span className="text-white">06:00 AM – 02:00 PM</span>
              </div>
            </div>

            <button
              onClick={() => setShowCallModal(true)}
              className="mt-4 w-full py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md shadow-emerald-950 transition-colors"
            >
              <Phone className="w-4 h-4" />
              <span>Contact Route Crew</span>
            </button>
          </div>

          {/* Vehicle Tech Specifications Card */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm space-y-3 text-xs">
            <h3 className="font-bold text-white text-sm pb-2 border-b border-slate-800">Vehicle Specifications</h3>
            
            <div className="flex justify-between">
              <span className="text-slate-400">Plate Number:</span>
              <span className="text-white font-mono font-bold">{currentTruck.plateNumber}</span>
            </div>
            
            <div className="flex justify-between">
              <span className="text-slate-400">Chassis Model:</span>
              <span className="text-white font-medium">{currentTruck.model}</span>
            </div>

            <div className="flex justify-between">
              <span className="text-slate-400">Battery / Fuel Level:</span>
              <span className="text-emerald-400 font-mono font-bold">{currentTruck.fuelPercentage}%</span>
            </div>

            <div className="flex justify-between">
              <span className="text-slate-400">GPS Telemetry Rate:</span>
              <span className="text-slate-300">Ping every 2 seconds</span>
            </div>

            <div className="flex justify-between">
              <span className="text-slate-400">Assigned Ward:</span>
              <span className="text-slate-300">{currentTruck.wardName}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Contact Crew Simulated Modal */}
      {showCallModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-sm w-full p-6 text-center space-y-4 shadow-2xl">
            <div className="w-16 h-16 rounded-full bg-emerald-950/80 border border-emerald-500 text-emerald-400 mx-auto flex items-center justify-center">
              <Phone className="w-8 h-8 animate-bounce" />
            </div>

            <div>
              <h4 className="text-lg font-bold text-white">Call Driver {currentTruck.driverName}</h4>
              <p className="text-xs text-slate-400 mt-1">
                Truck {currentTruck.truckNumber} ({currentTruck.driverPhone})
              </p>
            </div>

            <div className="p-3 rounded-lg bg-slate-800 text-xs text-slate-300">
              For safety reasons, calls connect to the co-driver helper ({currentTruck.helperName}) while vehicle is in motion.
            </div>

            {isCalling ? (
              <div className="p-3 bg-amber-950/50 border border-amber-800 rounded-lg text-amber-300 text-xs animate-pulse">
                Connecting to in-cabin hands-free intercom...
              </div>
            ) : callEnded ? (
              <div className="p-3 bg-emerald-950/50 border border-emerald-800 rounded-lg text-emerald-300 text-xs">
                ✓ Helper answered: "We are at Maple Lane, will reach your house in 8 minutes!"
              </div>
            ) : (
              <div className="flex gap-2">
                <button
                  onClick={() => setShowCallModal(false)}
                  className="flex-1 py-2 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSimulateCall}
                  className="flex-1 py-2 px-3 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center justify-center gap-1.5"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>Start Call</span>
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
