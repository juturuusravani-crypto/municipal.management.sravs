import React, { useState } from 'react';
import { 
  Calendar, 
  MapPin, 
  Clock, 
  Truck, 
  Bell, 
  Download, 
  Printer, 
  CheckCircle2, 
  Filter, 
  Leaf, 
  Recycle, 
  AlertTriangle,
  Info
} from 'lucide-react';
import { ScheduleItem, Ward, WasteType } from '../types';
import { SCHEDULES, WARDS } from '../data/mockData';

interface ScheduleViewProps {
  currentWard: Ward;
  allWards: Ward[];
  onSelectWard: (ward: Ward) => void;
  isSeniorMode: boolean;
}

export const ScheduleView: React.FC<ScheduleViewProps> = ({
  currentWard,
  allWards,
  onSelectWard,
  isSeniorMode,
}) => {
  const [selectedWasteType, setSelectedWasteType] = useState<string>('all');
  const [reminders, setReminders] = useState<{ [key: string]: boolean }>({
    'sch-1': true,
    'sch-2': true,
  });
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  // Filter schedules by ward and waste type
  const filteredSchedules = SCHEDULES.filter((s) => {
    const matchesWard = s.wardId === currentWard.id;
    const matchesType = selectedWasteType === 'all' || s.wasteType === selectedWasteType;
    return matchesWard && matchesType;
  });

  const toggleReminder = (id: string) => {
    setReminders((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  const handleDownload = () => {
    setDownloadSuccess(true);
    setTimeout(() => setDownloadSuccess(false), 2500);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className={`font-extrabold text-white tracking-tight ${isSeniorMode ? 'text-3xl' : 'text-2xl'}`}>
            Municipal Collection Schedule
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Weekly route timetable and waste segregation days for {currentWard.name}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleDownload}
            className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold flex items-center gap-2 transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4 text-emerald-400" />
            <span>{downloadSuccess ? 'Downloaded PDF!' : 'Export PDF Schedule'}</span>
          </button>
        </div>
      </div>

      {/* Ward Filter & Waste Type Segmented Controls */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        {/* Ward Selector Dropdown */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400 font-semibold whitespace-nowrap">Filter Ward:</span>
          <select
            value={currentWard.id}
            onChange={(e) => {
              const found = allWards.find((w) => w.id === e.target.value);
              if (found) onSelectWard(found);
            }}
            className="bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-2 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
          >
            {allWards.map((w) => (
              <option key={w.id} value={w.id}>
                {w.name} ({w.zone})
              </option>
            ))}
          </select>
        </div>

        {/* Waste Type Filter Buttons */}
        <div className="flex items-center flex-wrap gap-1.5 p-1 bg-slate-800/80 rounded-xl border border-slate-700/60">
          <button
            onClick={() => setSelectedWasteType('all')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
              selectedWasteType === 'all'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            All Categories
          </button>

          <button
            onClick={() => setSelectedWasteType('organic')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 ${
              selectedWasteType === 'organic'
                ? 'bg-emerald-700 text-white shadow-sm'
                : 'text-emerald-400 hover:text-emerald-300'
            }`}
          >
            <Leaf className="w-3.5 h-3.5" />
            <span>Organic (Green)</span>
          </button>

          <button
            onClick={() => setSelectedWasteType('recyclable')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 ${
              selectedWasteType === 'recyclable'
                ? 'bg-sky-700 text-white shadow-sm'
                : 'text-sky-400 hover:text-sky-300'
            }`}
          >
            <Recycle className="w-3.5 h-3.5" />
            <span>Recyclables (Blue)</span>
          </button>

          <button
            onClick={() => setSelectedWasteType('hazardous')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 ${
              selectedWasteType === 'hazardous'
                ? 'bg-amber-700 text-white shadow-sm'
                : 'text-amber-400 hover:text-amber-300'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>E-Waste & Hazardous</span>
          </button>
        </div>
      </div>

      {/* Schedule Table / Cards */}
      <div className="space-y-4">
        {filteredSchedules.length === 0 ? (
          <div className="p-12 text-center bg-slate-900 border border-slate-800 rounded-2xl">
            <Calendar className="w-12 h-12 text-slate-600 mx-auto mb-3" />
            <h3 className="text-white font-bold text-base">No collections scheduled</h3>
            <p className="text-slate-400 text-xs mt-1">Try switching categories or select another municipal ward.</p>
          </div>
        ) : (
          filteredSchedules.map((item) => {
            const isReminderActive = reminders[item.id] || false;

            return (
              <div
                key={item.id}
                className="bg-slate-900 border border-slate-800 rounded-2xl p-5 hover:border-slate-700 transition-all shadow-sm"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  {/* Left: Day & Timing */}
                  <div className="flex items-start gap-4">
                    <div className={`w-12 h-12 rounded-xl flex flex-col items-center justify-center font-bold shrink-0 ${
                      item.wasteType === 'organic'
                        ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                        : item.wasteType === 'recyclable'
                        ? 'bg-sky-950 text-sky-400 border border-sky-800'
                        : 'bg-amber-950 text-amber-400 border border-amber-800'
                    }`}>
                      <Calendar className="w-5 h-5 mb-0.5" />
                      <span className="text-[10px] uppercase">{item.dayOfWeek.slice(0, 3)}</span>
                    </div>

                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className={`font-bold text-white ${isSeniorMode ? 'text-lg' : 'text-base'}`}>
                          {item.dayOfWeek}
                        </h3>
                        <span className="text-xs text-slate-400 font-mono">({item.date})</span>

                        <span className={`px-2 py-0.5 text-[10px] font-bold rounded uppercase tracking-wider ${
                          item.status === 'in_progress'
                            ? 'bg-emerald-950 text-emerald-300 border border-emerald-800 animate-pulse'
                            : item.status === 'completed'
                            ? 'bg-slate-800 text-slate-400'
                            : 'bg-sky-950 text-sky-300 border border-sky-800'
                        }`}>
                          {item.status.replace('_', ' ')}
                        </span>
                      </div>

                      <div className="flex items-center gap-3 mt-1.5 text-xs text-slate-300 flex-wrap">
                        <div className="flex items-center gap-1.5 font-medium text-emerald-400">
                          <Clock className="w-3.5 h-3.5" />
                          <span>{item.timeSlot}</span>
                        </div>
                        <span className="text-slate-600">·</span>
                        <div className="flex items-center gap-1.5">
                          <Truck className="w-3.5 h-3.5 text-slate-400" />
                          <span className="font-semibold text-white">{item.truckNumber}</span>
                          <span className="text-slate-400">({item.driverName})</span>
                        </div>
                      </div>

                      {item.notes && (
                        <p className="mt-2 text-xs text-slate-400 leading-relaxed">
                          {item.notes}
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Right: Waste Category Badge & Reminder Toggle */}
                  <div className="flex items-center justify-between sm:justify-end gap-3 pt-3 sm:pt-0 border-t sm:border-t-0 border-slate-800">
                    <span className={`text-xs font-bold px-3 py-1 rounded-lg ${
                      item.wasteType === 'organic'
                        ? 'bg-emerald-900/60 text-emerald-300 border border-emerald-700'
                        : item.wasteType === 'recyclable'
                        ? 'bg-sky-900/60 text-sky-300 border border-sky-700'
                        : 'bg-amber-900/60 text-amber-300 border border-amber-700'
                    }`}>
                      {item.wasteType === 'organic' ? '🌱 Green Bin Organic' : item.wasteType === 'recyclable' ? '♻️ Blue Bin Recyclable' : '⚠️ Hazardous Drive'}
                    </span>

                    <button
                      onClick={() => toggleReminder(item.id)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                        isReminderActive
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                          : 'bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-700'
                      }`}
                      title="Receive SMS / Push alert before truck arrives"
                    >
                      <Bell className="w-3.5 h-3.5" />
                      <span>{isReminderActive ? 'Alert Set' : 'Set Alert'}</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Segregation Rules Quick Callout */}
      <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-start gap-3 text-xs text-slate-300">
        <Info className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <p className="font-bold text-white">Curbside Bin Placement Guidelines:</p>
          <p className="text-slate-400 leading-relaxed">
            Please place bins outside before 08:00 AM on your scheduled collection days with the lid handles facing your house. Keep at least 0.5 meters of clearance around the bin for automated hydraulic arms.
          </p>
        </div>
      </div>
    </div>
  );
};
