import React, { useState } from 'react';
import { 
  Bell, 
  CheckCircle2, 
  AlertTriangle, 
  Clock, 
  Calendar, 
  ShieldAlert, 
  Volume2, 
  Settings, 
  Check, 
  Trash2,
  Radio,
  Sliders
} from 'lucide-react';
import { CivicNotification } from '../types';

interface NotificationsViewProps {
  notifications: CivicNotification[];
  onMarkAsRead: (id: string) => void;
  onMarkAllAsRead: () => void;
  isSeniorMode: boolean;
}

export const NotificationsView: React.FC<NotificationsViewProps> = ({
  notifications,
  onMarkAsRead,
  onMarkAllAsRead,
  isSeniorMode,
}) => {
  const [filter, setFilter] = useState<'all' | 'unread' | 'alerts'>('all');
  const [pushEnabled, setPushEnabled] = useState(true);
  const [smsEnabled, setSmsEnabled] = useState(true);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [alertDistanceThreshold, setAlertDistanceThreshold] = useState<'5min' | '10min' | '15min'>('10min');
  const [showSettings, setShowSettings] = useState(false);

  const filtered = notifications.filter((n) => {
    if (filter === 'unread') return !n.read;
    if (filter === 'alerts') return n.type === 'delay' || n.type === 'emergency';
    return true;
  });

  const getIcon = (type: CivicNotification['type']) => {
    switch (type) {
      case 'arrival':
        return <Radio className="w-5 h-5 text-amber-400" />;
      case 'completed':
        return <CheckCircle2 className="w-5 h-5 text-emerald-400" />;
      case 'delay':
        return <AlertTriangle className="w-5 h-5 text-rose-400" />;
      case 'schedule_change':
        return <Calendar className="w-5 h-5 text-sky-400" />;
      case 'emergency':
        return <ShieldAlert className="w-5 h-5 text-red-400" />;
      default:
        return <Bell className="w-5 h-5 text-slate-400" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className={`font-extrabold text-white tracking-tight ${isSeniorMode ? 'text-3xl' : 'text-2xl'}`}>
            Civic Alerts & Notifications
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Real-time route updates, delay bulletins, and curbside collection warnings
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowSettings(!showSettings)}
            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold flex items-center gap-2 transition-colors"
          >
            <Sliders className="w-4 h-4 text-emerald-400" />
            <span>Alert Preferences</span>
          </button>

          <button
            onClick={onMarkAllAsRead}
            className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            <Check className="w-4 h-4" />
            <span>Mark All Read</span>
          </button>
        </div>
      </div>

      {/* Preferences Drawer / Accordion */}
      {showSettings && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm space-y-4">
          <h3 className="font-bold text-white text-sm pb-2 border-b border-slate-800">
            Citizen Alert Preferences
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <label className="flex items-center justify-between p-3 rounded-xl bg-slate-800/80 border border-slate-700 cursor-pointer">
              <span className="text-white font-medium">Push Notifications</span>
              <input
                type="checkbox"
                checked={pushEnabled}
                onChange={(e) => setPushEnabled(e.target.checked)}
                className="rounded text-emerald-600 focus:ring-emerald-500 bg-slate-900"
              />
            </label>

            <label className="flex items-center justify-between p-3 rounded-xl bg-slate-800/80 border border-slate-700 cursor-pointer">
              <span className="text-white font-medium">SMS Arrival Alerts</span>
              <input
                type="checkbox"
                checked={smsEnabled}
                onChange={(e) => setSmsEnabled(e.target.checked)}
                className="rounded text-emerald-600 focus:ring-emerald-500 bg-slate-900"
              />
            </label>

            <label className="flex items-center justify-between p-3 rounded-xl bg-slate-800/80 border border-slate-700 cursor-pointer">
              <span className="text-white font-medium">Chime Audio Buzzer</span>
              <input
                type="checkbox"
                checked={soundEnabled}
                onChange={(e) => setSoundEnabled(e.target.checked)}
                className="rounded text-emerald-600 focus:ring-emerald-500 bg-slate-900"
              />
            </label>
          </div>

          <div className="pt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
            <span className="text-slate-400">Trigger notification when truck is:</span>
            <div className="flex gap-2">
              {(['5min', '10min', '15min'] as const).map((thr) => (
                <button
                  key={thr}
                  onClick={() => setAlertDistanceThreshold(thr)}
                  className={`px-3 py-1 rounded-lg font-semibold transition-all ${
                    alertDistanceThreshold === thr
                      ? 'bg-emerald-600 text-white'
                      : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {thr === '5min' ? '5 Mins Away' : thr === '10min' ? '10 Mins (Recommended)' : '15 Mins Away'}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Filter Tabs */}
      <div className="flex gap-2 p-1 bg-slate-900 border border-slate-800 rounded-xl w-fit">
        <button
          onClick={() => setFilter('all')}
          className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
            filter === 'all' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          All Updates ({notifications.length})
        </button>
        <button
          onClick={() => setFilter('unread')}
          className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
            filter === 'unread' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Unread ({notifications.filter((n) => !n.read).length})
        </button>
        <button
          onClick={() => setFilter('alerts')}
          className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
            filter === 'alerts' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Delays & Emergencies
        </button>
      </div>

      {/* Notifications List */}
      <div className="space-y-3">
        {filtered.map((item) => (
          <div
            key={item.id}
            onClick={() => onMarkAsRead(item.id)}
            className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-start justify-between gap-4 ${
              !item.read
                ? 'bg-slate-900 border-slate-700/80 shadow-md ring-1 ring-emerald-500/20'
                : 'bg-slate-900/60 border-slate-800/80 opacity-80 hover:opacity-100'
            }`}
          >
            <div className="flex items-start gap-3.5">
              <div className="p-2.5 rounded-xl bg-slate-800 border border-slate-700/80 shrink-0">
                {getIcon(item.type)}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className={`font-bold ${!item.read ? 'text-white' : 'text-slate-300'} text-sm`}>
                    {item.title}
                  </h3>
                  {!item.read && (
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                  )}
                  {item.priority === 'critical' && (
                    <span className="px-1.5 py-0.5 text-[9px] font-bold rounded bg-rose-950 text-rose-300 border border-rose-800 uppercase">
                      CRITICAL
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-300 mt-1 leading-relaxed">{item.message}</p>
              </div>
            </div>

            <div className="text-right shrink-0">
              <span className="text-[11px] text-slate-400 font-mono block">{item.timestamp}</span>
              {item.truckNumber && (
                <span className="text-[10px] text-emerald-400 font-bold block mt-1">
                  {item.truckNumber}
                </span>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
