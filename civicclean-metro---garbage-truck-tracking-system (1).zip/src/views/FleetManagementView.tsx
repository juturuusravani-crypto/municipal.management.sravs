import React, { useState } from 'react';
import { 
  Truck, 
  User, 
  ShieldCheck, 
  Plus, 
  Edit, 
  Wrench, 
  MapPin, 
  Phone, 
  CheckCircle2, 
  AlertTriangle, 
  Filter, 
  Search,
  Battery,
  Fuel,
  History
} from 'lucide-react';
import { Truck as TruckType, Ward, TruckStatus } from '../types';

interface FleetManagementViewProps {
  trucks: TruckType[];
  wards: Ward[];
  onAddTruck: (truck: TruckType) => void;
  onUpdateTruckStatus: (id: string, status: TruckStatus) => void;
  isSeniorMode: boolean;
}

export const FleetManagementView: React.FC<FleetManagementViewProps> = ({
  trucks,
  wards,
  onAddTruck,
  onUpdateTruckStatus,
  isSeniorMode,
}) => {
  const [activeTab, setActiveTab] = useState<'trucks' | 'drivers' | 'history'>('trucks');
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showAssignModal, setShowAssignModal] = useState<TruckType | null>(null);

  // New truck form state
  const [newTruckNumber, setNewTruckNumber] = useState('GT-120');
  const [newPlate, setNewPlate] = useState('MUN-9920-FL');
  const [newModel, setNewModel] = useState('Volvo FE Electric Compactor');
  const [newCapacity, setNewCapacity] = useState('12');
  const [newDriver, setNewDriver] = useState('Tariq Al-Mansoor');
  const [newWard, setNewWard] = useState('ward-4');

  const filteredTrucks = trucks.filter((t) => {
    const matchesSearch = 
      t.truckNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.driverName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.plateNumber.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || t.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleCreateTruck = (e: React.FormEvent) => {
    e.preventDefault();
    const created: TruckType = {
      id: `truck-${Date.now()}`,
      truckNumber: newTruckNumber,
      plateNumber: newPlate,
      model: newModel,
      capacityTons: Number(newCapacity),
      currentLoadPercentage: 0,
      fuelPercentage: 100,
      speedKmh: 0,
      driverName: newDriver,
      driverPhone: '+1 (555) 888-1234',
      driverRating: 4.9,
      driverAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80',
      helperName: 'Ken Adams',
      wardId: newWard,
      wardName: wards.find(w => w.id === newWard)?.name || 'Ward 4',
      status: 'in_depot',
      estimatedArrivalMinutes: 60,
      distanceMeters: 2500,
      currentLocation: { x: 30, y: 30 },
      heading: 0,
      currentStopIndex: 0,
      lastUpdated: 'Just added',
      routeStops: [],
    };
    onAddTruck(created);
    setShowAddModal(false);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className={`font-extrabold text-white tracking-tight ${isSeniorMode ? 'text-3xl' : 'text-2xl'}`}>
            Fleet & Driver Management
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Maintain municipal waste vehicles, driver rosters, route assignments and maintenance schedules
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowAddModal(true)}
            className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 transition-colors shadow-md shadow-emerald-950 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Add New Truck</span>
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-4 rounded-2xl">
        <div className="flex gap-1.5 p-1 bg-slate-800/80 rounded-xl border border-slate-700/60">
          <button
            onClick={() => setActiveTab('trucks')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
              activeTab === 'trucks'
                ? 'bg-sky-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Truck className="w-4 h-4" />
            <span>Vehicle Fleet ({trucks.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('drivers')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
              activeTab === 'drivers'
                ? 'bg-sky-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <User className="w-4 h-4" />
            <span>Driver Roster</span>
          </button>

          <button
            onClick={() => setActiveTab('history')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
              activeTab === 'history'
                ? 'bg-sky-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <History className="w-4 h-4" />
            <span>Trip Logs</span>
          </button>
        </div>

        {/* Search & Status Filter */}
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-500" />
            <input
              type="text"
              placeholder="Search plate, truck, or driver..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 pr-3 py-1.5 bg-slate-800 border border-slate-700 rounded-lg text-white text-xs focus:outline-none focus:ring-2 focus:ring-sky-500 w-56 sm:w-64"
            />
          </div>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="p-1.5 bg-slate-800 border border-slate-700 rounded-lg text-white text-xs focus:outline-none focus:ring-2 focus:ring-sky-500"
          >
            <option value="all">All Statuses</option>
            <option value="on_route">On Route</option>
            <option value="delayed">Delayed</option>
            <option value="in_depot">In Depot</option>
            <option value="maintenance">Maintenance</option>
          </select>
        </div>
      </div>

      {/* Main Content Area */}
      {activeTab === 'trucks' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredTrucks.map((truck) => (
            <div
              key={truck.id}
              className="bg-slate-900 border border-slate-800 rounded-2xl p-5 hover:border-slate-700 transition-all flex flex-col justify-between shadow-sm"
            >
              <div>
                <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-800">
                  <div className="flex items-center gap-2.5">
                    <div className="w-10 h-10 rounded-xl bg-sky-950/80 border border-sky-700/60 flex items-center justify-center text-sky-400">
                      <Truck className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-bold text-white text-base">{truck.truckNumber}</h3>
                      <span className="text-[11px] text-slate-400 font-mono">{truck.plateNumber}</span>
                    </div>
                  </div>

                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                    truck.status === 'on_route'
                      ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                      : truck.status === 'delayed'
                      ? 'bg-rose-950 text-rose-300 border border-rose-800'
                      : truck.status === 'maintenance'
                      ? 'bg-amber-950 text-amber-300 border border-amber-800'
                      : 'bg-slate-800 text-slate-400'
                  }`}>
                    {truck.status.replace('_', ' ')}
                  </span>
                </div>

                <div className="space-y-2 text-xs text-slate-300">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Assigned Driver:</span>
                    <span className="text-white font-medium">{truck.driverName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Assigned Ward:</span>
                    <span className="text-slate-200">{truck.wardName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Chassis & Body:</span>
                    <span className="text-slate-200 truncate max-w-[150px]">{truck.model}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Payload Capacity:</span>
                    <span className="text-slate-200 font-mono">{truck.capacityTons} Metric Tons</span>
                  </div>

                  {/* Load Bar */}
                  <div className="pt-2">
                    <div className="flex justify-between text-[11px] mb-1">
                      <span className="text-slate-400">Current Load (% full)</span>
                      <span className="text-sky-400 font-mono font-bold">{truck.currentLoadPercentage}%</span>
                    </div>
                    <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full ${
                          truck.currentLoadPercentage > 85 ? 'bg-amber-500' : 'bg-sky-500'
                        }`}
                        style={{ width: `${truck.currentLoadPercentage}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Status Actions */}
              <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between gap-2">
                <button
                  onClick={() => setShowAssignModal(truck)}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold"
                >
                  Assign Route
                </button>

                <div className="flex items-center gap-1">
                  {truck.status !== 'maintenance' ? (
                    <button
                      onClick={() => onUpdateTruckStatus(truck.id, 'maintenance')}
                      className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-amber-950 text-amber-400 text-xs font-semibold flex items-center gap-1 border border-slate-700 hover:border-amber-700"
                      title="Send vehicle to maintenance workshop"
                    >
                      <Wrench className="w-3.5 h-3.5" />
                      <span>Service</span>
                    </button>
                  ) : (
                    <button
                      onClick={() => onUpdateTruckStatus(truck.id, 'on_route')}
                      className="px-2.5 py-1.5 rounded-lg bg-emerald-950 text-emerald-300 text-xs font-semibold flex items-center gap-1 border border-emerald-700"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Deploy</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'drivers' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-sm">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-800/80 border-b border-slate-700 text-slate-300 uppercase tracking-wider text-[10px]">
                <th className="p-3.5">Driver & Photo</th>
                <th className="p-3.5">Contact Phone</th>
                <th className="p-3.5">Assigned Vehicle</th>
                <th className="p-3.5">Ward Route</th>
                <th className="p-3.5">Rating</th>
                <th className="p-3.5">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {trucks.map((t) => (
                <tr key={t.id} className="hover:bg-slate-800/40">
                  <td className="p-3.5 flex items-center gap-3">
                    <img
                      src={t.driverAvatar}
                      alt={t.driverName}
                      className="w-9 h-9 rounded-full object-cover border border-slate-600"
                    />
                    <div>
                      <div className="font-bold text-white text-sm">{t.driverName}</div>
                      <div className="text-[10px] text-slate-400">Co-driver: {t.helperName}</div>
                    </div>
                  </td>
                  <td className="p-3.5 font-mono text-slate-300">{t.driverPhone}</td>
                  <td className="p-3.5 font-bold text-emerald-400 font-mono">{t.truckNumber}</td>
                  <td className="p-3.5 text-slate-300">{t.wardName}</td>
                  <td className="p-3.5 font-bold text-amber-400">★ {t.driverRating}</td>
                  <td className="p-3.5">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-800">
                      ON DUTY
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {activeTab === 'history' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-sm">
          <h3 className="font-bold text-white text-base">Completed Route Archives (Last 24 Hours)</h3>
          <div className="space-y-3">
            {[
              { time: '08:45 AM', truck: 'GT-104', ward: 'Ward 4', stops: '8 stops', tons: '4.8 Tons', status: 'On Schedule' },
              { time: '08:15 AM', truck: 'GT-105', ward: 'Ward 1', stops: '12 stops', tons: '6.2 Tons', status: 'Completed 100%' },
              { time: '07:30 AM', truck: 'GT-108', ward: 'Ward 2', stops: '9 stops', tons: '5.1 Tons', status: 'Completed 100%' },
              { time: 'Yesterday', truck: 'GT-102', ward: 'Ward 4', stops: '10 stops', tons: '5.6 Tons', status: 'Completed' },
            ].map((log, i) => (
              <div key={i} className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700/80 flex items-center justify-between text-xs">
                <div className="flex items-center gap-3">
                  <span className="font-mono text-slate-400">{log.time}</span>
                  <span className="font-bold text-white">{log.truck}</span>
                  <span className="text-slate-400">·</span>
                  <span className="text-slate-300">{log.ward}</span>
                  <span className="text-slate-400">·</span>
                  <span className="text-emerald-400 font-semibold">{log.tons} collected</span>
                </div>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-800">
                  {log.status}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Modal: Add New Truck */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="font-bold text-white text-base">Register New Fleet Truck</h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateTruck} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-400 font-semibold mb-1">Truck Vehicle ID</label>
                <input
                  type="text"
                  value={newTruckNumber}
                  onChange={(e) => setNewTruckNumber(e.target.value)}
                  className="w-full p-2 bg-slate-800 border border-slate-700 rounded-lg text-white"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">License Plate Number</label>
                <input
                  type="text"
                  value={newPlate}
                  onChange={(e) => setNewPlate(e.target.value)}
                  className="w-full p-2 bg-slate-800 border border-slate-700 rounded-lg text-white"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Payload (Tons)</label>
                  <input
                    type="number"
                    value={newCapacity}
                    onChange={(e) => setNewCapacity(e.target.value)}
                    className="w-full p-2 bg-slate-800 border border-slate-700 rounded-lg text-white"
                    required
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Assigned Ward</label>
                  <select
                    value={newWard}
                    onChange={(e) => setNewWard(e.target.value)}
                    className="w-full p-2 bg-slate-800 border border-slate-700 rounded-lg text-white"
                  >
                    {wards.map((w) => (
                      <option key={w.id} value={w.id}>
                        {w.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">Primary Driver Name</label>
                <input
                  type="text"
                  value={newDriver}
                  onChange={(e) => setNewDriver(e.target.value)}
                  className="w-full p-2 bg-slate-800 border border-slate-700 rounded-lg text-white"
                  required
                />
              </div>

              <div className="pt-3 flex gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 py-2 rounded-lg bg-slate-800 text-slate-300 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold"
                >
                  Save Truck
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Assign Route */}
      {showAssignModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-sm w-full p-6 space-y-4 shadow-2xl">
            <h3 className="font-bold text-white text-base">Reassign {showAssignModal.truckNumber} Route</h3>
            <p className="text-xs text-slate-400">
              Select new municipal ward zone and dispatch shift.
            </p>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-400 font-semibold mb-1">Target Ward Zone</label>
                <select className="w-full p-2 bg-slate-800 border border-slate-700 rounded-lg text-white">
                  {wards.map((w) => (
                    <option key={w.id} value={w.id}>
                      {w.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">Shift Timing</label>
                <select className="w-full p-2 bg-slate-800 border border-slate-700 rounded-lg text-white">
                  <option>Morning (06:00 AM – 02:00 PM)</option>
                  <option>Afternoon (02:00 PM – 10:00 PM)</option>
                  <option>Night Commercial Sweep (10:00 PM – 06:00 AM)</option>
                </select>
              </div>
            </div>

            <div className="pt-3 flex gap-2">
              <button
                onClick={() => setShowAssignModal(null)}
                className="flex-1 py-2 rounded-lg bg-slate-800 text-slate-300 text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                onClick={() => setShowAssignModal(null)}
                className="flex-1 py-2 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold"
              >
                Confirm Dispatch
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
