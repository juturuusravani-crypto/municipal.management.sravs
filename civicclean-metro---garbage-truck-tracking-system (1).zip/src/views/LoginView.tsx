import React, { useState } from 'react';
import { 
  Truck, 
  ShieldCheck, 
  User, 
  Lock, 
  Phone, 
  ArrowRight, 
  MapPin, 
  Sparkles,
  Info,
  CheckCircle2,
  Building2,
  BadgeCheck
} from 'lucide-react';
import { UserRole, UserProfile } from '../types';
import { DEMO_USERS, WARDS } from '../data/mockData';

interface LoginViewProps {
  onLoginSuccess: (user: UserProfile) => void;
  isSeniorMode: boolean;
  onToggleSeniorMode: () => void;
}

export const LoginView: React.FC<LoginViewProps> = ({
  onLoginSuccess,
  isSeniorMode,
  onToggleSeniorMode,
}) => {
  const [activeTab, setActiveTab] = useState<'citizen' | 'staff'>('citizen');
  const [phoneOrEmail, setPhoneOrEmail] = useState('+1 (555) 482-9019');
  const [otpOrPassword, setOtpOrPassword] = useState('8492');
  const [selectedWard, setSelectedWard] = useState('ward-4');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      if (activeTab === 'citizen') {
        const citizen = DEMO_USERS.find((u) => u.role === 'citizen') || DEMO_USERS[0];
        onLoginSuccess({
          ...citizen,
          wardId: selectedWard,
        });
      } else {
        const admin = DEMO_USERS.find((u) => u.role === 'admin') || DEMO_USERS[1];
        onLoginSuccess(admin);
      }
    }, 400);
  };

  const handleQuickDemoLogin = (role: UserRole) => {
    const user = DEMO_USERS.find((u) => u.role === role) || DEMO_USERS[0];
    onLoginSuccess(user);
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-slate-950 flex flex-col justify-center py-10 px-4 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center">
        {/* Civic Seal Emblem */}
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-emerald-600/20 border border-emerald-500/30 text-emerald-400 mb-4 shadow-lg">
          <Truck className="w-8 h-8" />
        </div>
        <h1 className={`font-extrabold text-white tracking-tight ${isSeniorMode ? 'text-3xl' : 'text-2xl'}`}>
          Municipal Waste Portal
        </h1>
        <p className="mt-1 text-xs sm:text-sm text-slate-400">
          City Department of Sanitation & Environmental Services
        </p>

        {/* Quick Role Switcher Banner */}
        <div className="mt-4 p-2 bg-slate-900 border border-slate-800 rounded-lg flex items-center justify-between text-xs">
          <span className="text-slate-400">⚡ Prototype Demo Quick-Access:</span>
          <div className="flex gap-1.5">
            <button
              onClick={() => handleQuickDemoLogin('citizen')}
              className="px-2 py-1 bg-emerald-700 hover:bg-emerald-600 text-white rounded text-[11px] font-semibold transition-colors"
            >
              Citizen
            </button>
            <button
              onClick={() => handleQuickDemoLogin('admin')}
              className="px-2 py-1 bg-sky-700 hover:bg-sky-600 text-white rounded text-[11px] font-semibold transition-colors"
            >
              Admin
            </button>
            <button
              onClick={() => handleQuickDemoLogin('driver')}
              className="px-2 py-1 bg-amber-700 hover:bg-amber-600 text-white rounded text-[11px] font-semibold transition-colors"
            >
              Driver
            </button>
          </div>
        </div>
      </div>

      <div className="mt-6 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-slate-900 border border-slate-800 py-8 px-6 shadow-xl rounded-2xl sm:px-10">
          {/* Tabs: Citizen vs Staff */}
          <div className="flex rounded-lg bg-slate-800/80 p-1 mb-6 border border-slate-700/60">
            <button
              type="button"
              onClick={() => {
                setActiveTab('citizen');
                setPhoneOrEmail('+1 (555) 482-9019');
              }}
              className={`flex-1 py-2 text-xs font-semibold rounded-md flex items-center justify-center gap-2 transition-all ${
                activeTab === 'citizen'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <User className="w-4 h-4" />
              <span>Resident Citizen</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveTab('staff');
                setPhoneOrEmail('arthur.ross@metro-sanitation.gov');
              }}
              className={`flex-1 py-2 text-xs font-semibold rounded-md flex items-center justify-center gap-2 transition-all ${
                activeTab === 'staff'
                  ? 'bg-sky-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <ShieldCheck className="w-4 h-4" />
              <span>Municipal Staff / Driver</span>
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {activeTab === 'citizen' ? (
              <>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Mobile Phone / Resident Account
                  </label>
                  <div className="relative">
                    <Phone className="w-4 h-4 absolute left-3 top-3 text-slate-500" />
                    <input
                      type="text"
                      value={phoneOrEmail}
                      onChange={(e) => setPhoneOrEmail(e.target.value)}
                      placeholder="+1 (555) 000-0000"
                      className="w-full pl-9 pr-3 py-2.5 bg-slate-800 border border-slate-700 rounded-lg text-white text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Select Your Municipal Ward / Neighborhood
                  </label>
                  <div className="relative">
                    <MapPin className="w-4 h-4 absolute left-3 top-3 text-slate-500" />
                    <select
                      value={selectedWard}
                      onChange={(e) => setSelectedWard(e.target.value)}
                      className="w-full pl-9 pr-3 py-2.5 bg-slate-800 border border-slate-700 rounded-lg text-white text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    >
                      {WARDS.map((w) => (
                        <option key={w.id} value={w.id}>
                          {w.name} ({w.zone})
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs font-medium text-slate-300">
                      SMS One-Time Passcode (OTP)
                    </label>
                    <span className="text-[11px] text-emerald-400 font-medium cursor-pointer">
                      Resend Code
                    </span>
                  </div>
                  <div className="relative">
                    <Lock className="w-4 h-4 absolute left-3 top-3 text-slate-500" />
                    <input
                      type="password"
                      value={otpOrPassword}
                      onChange={(e) => setOtpOrPassword(e.target.value)}
                      placeholder="Enter 4-digit code"
                      className="w-full pl-9 pr-3 py-2.5 bg-slate-800 border border-slate-700 rounded-lg text-white text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 tracking-widest font-mono"
                      required
                    />
                  </div>
                </div>
              </>
            ) : (
              <>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Municipal Staff Badge ID or Email
                  </label>
                  <div className="relative">
                    <BadgeCheck className="w-4 h-4 absolute left-3 top-3 text-slate-500" />
                    <input
                      type="text"
                      value={phoneOrEmail}
                      onChange={(e) => setPhoneOrEmail(e.target.value)}
                      placeholder="e.g. MUNI-ADM-042 or email"
                      className="w-full pl-9 pr-3 py-2.5 bg-slate-800 border border-slate-700 rounded-lg text-white text-sm focus:outline-none focus:ring-2 focus:ring-sky-500"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Department Security Key / Password
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 absolute left-3 top-3 text-slate-500" />
                    <input
                      type="password"
                      value={otpOrPassword}
                      onChange={(e) => setOtpOrPassword(e.target.value)}
                      placeholder="Enter municipal password"
                      className="w-full pl-9 pr-3 py-2.5 bg-slate-800 border border-slate-700 rounded-lg text-white text-sm focus:outline-none focus:ring-2 focus:ring-sky-500"
                      required
                    />
                  </div>
                </div>

                <div className="p-2.5 rounded-lg bg-sky-950/40 border border-sky-800/50 text-[11px] text-sky-300 flex items-start gap-2">
                  <Info className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
                  <span>
                    Fleet telematics and route dispatch tools require verified city staff credentials.
                  </span>
                </div>
              </>
            )}

            <button
              type="submit"
              disabled={isSubmitting}
              className={`w-full py-3 px-4 rounded-lg font-bold text-white flex items-center justify-center gap-2 transition-all ${
                activeTab === 'citizen'
                  ? 'bg-emerald-600 hover:bg-emerald-500 focus:ring-4 focus:ring-emerald-800 shadow-md shadow-emerald-950'
                  : 'bg-sky-600 hover:bg-sky-500 focus:ring-4 focus:ring-sky-800 shadow-md shadow-sky-950'
              } ${isSeniorMode ? 'text-lg py-3.5' : 'text-sm'}`}
            >
              {isSubmitting ? (
                <span>Authenticating...</span>
              ) : (
                <>
                  <span>{activeTab === 'citizen' ? 'Access Citizen Portal' : 'Login to Command Center'}</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          {/* Senior Accessibility Notice */}
          <div className="mt-6 pt-5 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
            <span>Elderly or Vision Impaired?</span>
            <button
              onClick={onToggleSeniorMode}
              className="text-amber-400 hover:underline font-semibold"
            >
              {isSeniorMode ? 'Disable Large Text' : 'Enable Large Text'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
